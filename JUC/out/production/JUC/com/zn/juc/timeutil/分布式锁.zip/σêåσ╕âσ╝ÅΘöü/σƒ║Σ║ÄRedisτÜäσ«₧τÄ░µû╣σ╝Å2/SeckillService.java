package com.zn.juc.timeutil.分布式锁.基于Redis的实现方式2;

public class SeckillService {
    private static
    int n = 500;
    public  void seckill() {
        String key = "lock:suo01";
        // 超时时间，上锁后超过此时间则自动释放锁
        int lockExpireTime = 1000 * 5;//5秒，毫秒为单位
        String tryGetDistributedLock = RedisLock2.tryGetDistributedLock(key, lockExpireTime);
        System.out.println(Thread.currentThread().getName()+"获取了锁！");
        System.out.println(--n);
        boolean releaseDistributedLock = RedisLock2.releaseDistributedLock(key, tryGetDistributedLock);
    }

    public static void main(String[] args) {
        SeckillService seckillService = new SeckillService();
        for (int i = 0; i < 2; i++) {
            new Thread(() -> {
                seckillService.seckill();
            },"抢购者-"+i).start();
        }
    }
}


