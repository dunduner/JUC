package com.zn.juc.timeutil.分布式锁.基于Redis的实现方式2;

import com.zn.juc.timeutil.分布式锁.基于Redis的实现方式1.RedisUtil;
import redis.clients.jedis.Jedis;

import java.util.Collections;
import java.util.UUID;

public class RedisLock2 {
    private static final String LOCK_SUCCESS = "OK";
    private static final String SET_IF_NOT_EXIST = "NX";
    private static final String SET_WITH_EXPIRE_TIME = "PX";
    /**
     * 尝试获取分布式锁   加锁
     * @param lockKey         锁  key
     * @param expireTime      超期时间-参数为多少毫秒
     * @return 是否获取成功
     */
    public static String tryGetDistributedLock(String lockKey, int expireTime) {
        Jedis conn = null;
        // 获取连接
        conn = RedisUtil.getJedis();
        String requestId_value = UUID.randomUUID().toString();//相当于redis的value
        String result = conn.set(lockKey, requestId_value, SET_IF_NOT_EXIST, SET_WITH_EXPIRE_TIME, expireTime);//豪秒
        if (LOCK_SUCCESS.equals(result)) {
            System.out.println(lockKey + "上锁成功！");
            return requestId_value;
        } else {
            System.out.println(lockKey + "上锁失败！");
            return null;
        }
    }

    /**
     * 释放分布式锁
     * @param jedis Redis客户端
     * @param lockKey 锁
     * @param requestId 请求标识
     * @return 是否释放成功
     */
    private static final Long RELEASE_SUCCESS = 1L;//解锁成功！
    public static boolean releaseDistributedLock(String lockKey, String requestId_value) {
        Jedis conn = null;
        // 获取连接
        conn = RedisUtil.getJedis();
        String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
        Object result = conn.eval(script, Collections.singletonList(lockKey), Collections.singletonList(requestId_value));
        System.out.println("解锁的result->:" + result.toString());
        if (RELEASE_SUCCESS.equals(result)) {
            System.out.println("key为：" + lockKey + "，解锁成功！");
            return true;
        }
        return false;
    }
}
