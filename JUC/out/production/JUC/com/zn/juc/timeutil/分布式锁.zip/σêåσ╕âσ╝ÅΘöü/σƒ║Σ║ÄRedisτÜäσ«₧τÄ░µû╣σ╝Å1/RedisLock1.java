package com.zn.juc.timeutil.分布式锁.基于Redis的实现方式1;

import redis.clients.jedis.Jedis;

import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class RedisLock1 {
    private static final String LOCK_SUCCESS = "OK";
    private static final String SET_IF_NOT_EXIST = "NX";
    private static final String SET_WITH_EXPIRE_TIME = "PX";
    private final Jedis jedis;

    public RedisLock1(Jedis jedis) {
        this.jedis = jedis;
    }

    /**
     * 尝试获取分布式锁   加锁
     *
     * @param jedis           Redis客户端
     * @param lockKey         锁  key
     * @param requestId_value 请求标识  value
     * @param expireTime      超期时间   参数为多少毫秒
     * @return 是否获取成功
     */
    public static boolean tryGetDistributedLock(Jedis jedis, String lockKey, String requestId_value, int expireTime) {
        String result = jedis.set(lockKey, requestId_value, SET_IF_NOT_EXIST, SET_WITH_EXPIRE_TIME, expireTime);//豪秒
        if (LOCK_SUCCESS.equals(result)) {
            System.out.println(lockKey + "上锁成功！");
            return true;
        } else {
            System.out.println(lockKey + "上锁失败！");
        }
        return false;
    }

    /**
     * 释放分布式锁
     *
     * @param jedis Redis客户端
     * @param lockKey 锁
     * @param requestId 请求标识
     * @return 是否释放成功
     */
    private static final Long RELEASE_SUCCESS = 1L;//解锁成功！

    public static boolean releaseDistributedLock(Jedis jedis, String lockKey, String requestId_value) {
        String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
        Object result = jedis.eval(script, Collections.singletonList(lockKey), Collections.singletonList(requestId_value));
        System.out.println("解锁的result->:" + result.toString());
        if (RELEASE_SUCCESS.equals(result)) {
            System.out.println("key为：" + lockKey + "，解锁成功！");
            return true;
        }
        return false;
    }


    public static void main(String[] args) throws Exception {
        AtomicInteger num = new AtomicInteger(10);
        Jedis jedis = RedisUtil.getJedis();
        String key = "lock:suo01";
        //requestId可以使用UUID.randomUUID().toString()方法生成
        String requestId_value = UUID.randomUUID().toString();//相当于redis的value
        // 超时时间，上锁后超过此时间则自动释放锁
        int lockExpireTime = 1000 * 60 * 5;//五分钟
        for (int i = 0; i < 50; i++) {
            new Thread(() -> {
                //上锁方法
                boolean b = tryGetDistributedLock(jedis, key, requestId_value, lockExpireTime);
                System.out.println(b ? "上锁成功,key->" + key + "||value:->" + requestId_value : "已经上锁");
                //TimeUnit.SECONDS.sleep(20);//线程休眠20秒
                //抢购逻辑
                int i1 = num.decrementAndGet();
                System.out.println(Thread.currentThread().getName()+"抢购成功，商品剩余"+i1+"个！");
                //解锁方法
                boolean releaseDistributedLockResult = releaseDistributedLock(jedis, key, jedis.get(key));
                System.out.println(releaseDistributedLockResult ? "解锁成功,key->" + key + "||value:->" + requestId_value : "解锁失败");
                RedisUtil.close(jedis);//最后释放连接
            }, "抢购者-" + i).start();
        }
    }
}
